package com.project.wallet;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.Optional;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import com.project.wallet.dto.TransferRequest;
import com.project.wallet.dto.TransferResponse;
import com.project.wallet.dto.UserDto;
import com.project.wallet.dto.UserResponse;
import com.project.wallet.dto.WalletBalanceResponse;
import com.project.wallet.dto.WalletDto;
import com.project.wallet.entity.Currency;
import com.project.wallet.entity.User;
import com.project.wallet.entity.Wallet;
import com.project.wallet.exception.ResourceNotFoundException;
import com.project.wallet.repository.UserRepository;
import com.project.wallet.repository.WalletRepository;
import com.project.wallet.service.impl.UserServiceImpl;
import com.project.wallet.service.impl.WalletServiceImpl;

@SpringBootTest
class WalletApplicationTests {

	    @Mock
	    private UserRepository userRepository;

	    @Mock
	    private WalletRepository walletRepository;

	    @InjectMocks
	    private UserServiceImpl userService;

	    @InjectMocks
	    private WalletServiceImpl walletService;

	    @BeforeEach
	    public void setup() {
	        MockitoAnnotations.openMocks(this);
	    }

	    // User Story 1: Register User
	    @Test
	    public void testRegisterUserSuccess() {
	    	UserDto request = new UserDto();
			request.setEmail("john@example.com");
			request.setPassword("pass123");
			request.setUsername("john");
	    	
	        User user = new User();
	        user.setId(1L);
	        user.setUsername("john");
	        user.setPassword("pass123");
	        user.setEmail("john@example.com");
	        
			request.setEmail("john@example.com");
			request.setPassword("pass123");
			request.setUsername("john");
			
	        when(userRepository.save(any(User.class))).thenReturn(user);

	        UserResponse response = userService.registerUser(request);
	        assertEquals("User account created successfully", response.getContent());
	    }

	    // User Story 2: Add Balance
	    @Test
	    public void testAddBalanceSuccess() {
	        User user = new User();
	        user.setId(1L);
	        user.setEmail("john@example.com");
	        user.setPassword("pass123");
	        user.setUsername("john");
	        
	        Currency currency = new Currency(1L, "Rupee", "Rs");
	        Wallet wallet = new Wallet();
	        wallet.setId(1L);
	        wallet.setUser(user);
	        wallet.setBalance(500.0);
	        wallet.setCurrency(currency);
	        WalletDto request = new WalletDto();

	        request.setUserId(1L);
	        request.setBalance(1000.0);
	        
	        when(userRepository.findById(1L)).thenReturn(Optional.of(user));
	        when(walletRepository.findByUser(user)).thenReturn(Optional.of(wallet));
	        when(walletRepository.save(any(Wallet.class))).thenReturn(wallet);

	        UserResponse response = walletService.addBalance(request);
	        assertEquals("Balance added successfully", response.getContent());
	    }

	    @Test
	    public void testAddBalanceUserNotFound() {
	    	WalletDto request = new WalletDto();
	        request.setUserId(99L);
	    	request.setBalance(1000.0);
	        when(userRepository.findById(99L)).thenReturn(Optional.empty());

	        assertThrows(ResourceNotFoundException.class, () -> walletService.addBalance(request));
	    }

	    // User Story 3: Check Balance
	    @Test
	    public void testCheckBalanceSuccess() {
	   
	        User user = new User();
	        user.setId(1L);
	        user.setEmail("john@example.com");
	        user.setPassword("pass123");
	        user.setUsername("john");
	        
	        Currency currency = new Currency(1L, "Rupee", "Rs");
	        
	        
	        Wallet wallet = new Wallet();
	        wallet.setId(1L);
	        wallet.setUser(user);
	        wallet.setBalance(500.0);
	        wallet.setCurrency(currency);

	        when(userRepository.findById(1L)).thenReturn(Optional.of(user));
	        when(walletRepository.findByUser(user)).thenReturn(Optional.of(wallet));

	        WalletBalanceResponse response = walletService.getWalletBalance(1L);
	        assertEquals(500.0, response.getBalance());
	        assertEquals("Rs", response.getCurrency());
	    }

	    @Test
	    public void testCheckBalanceUserNotFound() {
	        when(userRepository.findById(99L)).thenReturn(Optional.empty());
	        assertThrows(ResourceNotFoundException.class, () -> walletService.getWalletBalance(99L));
	    }

	    // User Story 4: Transfer Funds
	    @Test
	    public void testTransferFundsSuccess() {
	        
	        User user1 = new User();
	        user1.setId(1L);
	        user1.setEmail("john@example.com");
	        user1.setPassword("pass123");
	        user1.setUsername("john");
	        
	        User user2 = new User();
	        user2.setId(2L);
	        user2.setEmail("alice@example.com");
	        user2.setPassword("pass456");
	        user2.setUsername("alice");
	        
	        
	        Currency currency = new Currency(1L, "Rupee", "Rs");
	        
	        Wallet fromWallet = new Wallet();
	        fromWallet.setId(1L);
	        fromWallet.setUser(user1);
	        fromWallet.setCurrency(currency);
	        fromWallet.setBalance(10000.0);
	        
	        Wallet toWallet = new Wallet();
	        
	        toWallet.setId(2L);
	        toWallet.setUser(user2);
	        toWallet.setCurrency(currency);
	        toWallet.setBalance(5000.0);
	        
	        TransferRequest request = new TransferRequest();
	        
	        request.setWalletId(1L);
	        request.setToWalletId(2L);
	        request.setBalance(3000.0);

	        when(walletRepository.findById(1L)).thenReturn(Optional.of(fromWallet));
	        when(walletRepository.findById(2L)).thenReturn(Optional.of(toWallet));
	        when(walletRepository.save(any(Wallet.class))).thenReturn(fromWallet);

	        TransferResponse response = walletService.transferFunds(request);
	        assertEquals("Transfer successful", response.getContent());
	    }


}
