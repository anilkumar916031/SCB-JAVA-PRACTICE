package com.project.wallet.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.project.wallet.dto.TransferRequest;
import com.project.wallet.dto.TransferResponse;
import com.project.wallet.dto.UserResponse;
import com.project.wallet.dto.WalletBalanceResponse;
import com.project.wallet.dto.WalletDto;
import com.project.wallet.service.WalletService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/users")
public class WalletController {

    @Autowired
    private WalletService walletService;

    @PatchMapping("/wallet")
    public ResponseEntity<UserResponse> addBalance(@Validated @RequestBody WalletDto request) {
    	UserResponse response = walletService.addBalance(request);
        return ResponseEntity.ok(response);
    }
    
    @GetMapping("/{userId}")
    public ResponseEntity<WalletBalanceResponse> getWalletBalance(@PathVariable Long userId) {
    	WalletBalanceResponse response = walletService.getWalletBalance(userId);
        return ResponseEntity.ok(response);
    }
    
    @PostMapping("/transfer")
    public ResponseEntity<TransferResponse> transferFunds(@Valid @RequestBody TransferRequest request) {
        TransferResponse response = walletService.transferFunds(request);
        return ResponseEntity.ok(response);
    }
}