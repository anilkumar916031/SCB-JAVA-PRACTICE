package com.project.wallet.controller;

import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.EntityModel;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.project.wallet.dto.UserDto;
import com.project.wallet.dto.UserResponse;
import com.project.wallet.service.UserService;

@RestController
@RequestMapping("/users")
public class UserController {

    @Autowired
    private UserService userService;

    @PostMapping("/register")
    public ResponseEntity<UserResponse> registerUser(@Valid @RequestBody UserDto request) {
        UserResponse response = userService.registerUser(request);
        return ResponseEntity.status(201).body(response);
    }


    

}

