package com.project.wallet.dto;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;

public class TransferRequest {

    @NotNull(message = "Source walletId is required")
    private Long walletId;

    @NotNull(message = "Destination walletId is required")
    private Long toWalletId;

    @NotNull(message = "Transfer amount is required")
    @Min(value = 1, message = "Transfer amount must be greater than zero")
    private Double balance;

	public Long getWalletId() {
		return walletId;
	}

	public void setWalletId(Long walletId) {
		this.walletId = walletId;
	}

	public Long getToWalletId() {
		return toWalletId;
	}

	public void setToWalletId(Long toWalletId) {
		this.toWalletId = toWalletId;
	}

	public Double getBalance() {
		return balance;
	}

	public void setBalance(Double balance) {
		this.balance = balance;
	}
    
    
}
