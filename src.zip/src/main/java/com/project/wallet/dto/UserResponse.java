package com.project.wallet.dto;

public class UserResponse {
	
    private String content;
    private String selfLink;

    public UserResponse(String content, String selfLink) {
        this.content = content;
        this.selfLink = selfLink;
    }

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public String getSelfLink() {
		return selfLink;
	}

	public void setSelfLink(String selfLink) {
		this.selfLink = selfLink;
	}

   
}