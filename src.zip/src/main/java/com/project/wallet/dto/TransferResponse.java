package com.project.wallet.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

public class TransferResponse {
	
    private String content;
    

	public TransferResponse(String content) {
		this.content = content;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}
    
    
}
