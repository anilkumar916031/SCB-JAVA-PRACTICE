package com.project.wallet.dto;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;

public class WalletDto {

    @NotNull(message = "User ID is required")
    private Long userId;

    @Min(value = 1, message = "Balance must be greater than zero")
    private double balance;

	// Getters and Setters
    public Long getUserId() { return userId; }
    public void setUserId(Long userId) { this.userId = userId; }

    public double getBalance() { return balance; }
    public void setBalance(double balance) { this.balance = balance; }
}
