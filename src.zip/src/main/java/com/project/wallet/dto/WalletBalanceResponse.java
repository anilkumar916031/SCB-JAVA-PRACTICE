package com.project.wallet.dto;

public class WalletBalanceResponse {

    private Long userId;
    private Double balance;
    private String currency;
    

    public WalletBalanceResponse(Long userId, Double balance, String currency) {
        this.userId = userId;
        this.balance = balance;
        this.currency = currency;
    }
 
	public Long getUserId() {
		return userId;
	}
	public void setUserId(Long userId) {
		this.userId = userId;
	}
	public Double getBalance() {
		return balance;
	}
	public void setBalance(Double balance) {
		this.balance = balance;
	}
	public String getCurrency() {
		return currency;
	}
	public void setCurrency(String currency) {
		this.currency = currency;
	}
    
    
    
}
