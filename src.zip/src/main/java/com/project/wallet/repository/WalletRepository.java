package com.project.wallet.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.project.wallet.entity.User;
import com.project.wallet.entity.Wallet;

public interface WalletRepository extends JpaRepository<Wallet, Long> {

    // Find wallet by associated user
    Optional<Wallet> findByUser(User user);
}


