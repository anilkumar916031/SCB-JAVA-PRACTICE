package com.project.wallet.service;

import com.project.wallet.dto.UserDto;
import com.project.wallet.dto.UserResponse;

public interface UserService {
	    UserResponse registerUser(UserDto request);
	}

