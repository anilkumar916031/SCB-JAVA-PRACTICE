package com.project.wallet.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.project.wallet.dto.TransferRequest;
import com.project.wallet.dto.TransferResponse;
import com.project.wallet.dto.UserResponse;
import com.project.wallet.dto.WalletBalanceResponse;
import com.project.wallet.dto.WalletDto;
import com.project.wallet.entity.User;
import com.project.wallet.entity.Wallet;
import com.project.wallet.exception.ResourceNotFoundException;
import com.project.wallet.repository.UserRepository;
import com.project.wallet.repository.WalletRepository;
import com.project.wallet.service.WalletService;

@Service
public class WalletServiceImpl implements WalletService {

    @Autowired
    private WalletRepository walletRepository;

    @Autowired
    private UserRepository userRepository;

    @Override
    public UserResponse addBalance(WalletDto request) {
        User user = userRepository.findById(request.getUserId())
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));

        Wallet wallet = walletRepository.findByUser(user)
                .orElseThrow(() -> new ResourceNotFoundException("Wallet not found"));

        wallet.setBalance(wallet.getBalance() + request.getBalance());
        walletRepository.save(wallet);

        String link = "http://localhost:8090/users/" + user.getId() + "/wallet";
        return new UserResponse("Balance added successfully", link);
    }
    
    @Override
    public WalletBalanceResponse getWalletBalance(Long userId) {
        var user = userRepository.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));

        Wallet wallet = walletRepository.findByUser(user)
                .orElseThrow(() -> new ResourceNotFoundException("Wallet not found"));

        return new WalletBalanceResponse(user.getId(), wallet.getBalance(), wallet.getCurrency().getAbbreviation());
    }
    

    @Override
    @Transactional
    public TransferResponse transferFunds(TransferRequest request) {
    	
        Wallet fromWallet = walletRepository.findById(request.getWalletId())
                .orElseThrow(() -> new ResourceNotFoundException("Source wallet not found"));

        Wallet toWallet = walletRepository.findById(request.getToWalletId())
                .orElseThrow(() -> new ResourceNotFoundException("Destination wallet not found"));

        if (fromWallet.getBalance() < request.getBalance()) {
            throw new ResourceNotFoundException("Insufficient balance. Kindly review your balance.");
        }

        fromWallet.setBalance(fromWallet.getBalance() - request.getBalance());
        toWallet.setBalance(toWallet.getBalance() + request.getBalance());

        walletRepository.save(fromWallet);
        walletRepository.save(toWallet);

      
        return new TransferResponse("Transfer successful");
    }
}
