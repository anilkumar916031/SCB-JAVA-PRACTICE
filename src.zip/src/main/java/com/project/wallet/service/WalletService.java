package com.project.wallet.service;

import com.project.wallet.dto.TransferRequest;
import com.project.wallet.dto.TransferResponse;
import com.project.wallet.dto.UserResponse;
import com.project.wallet.dto.WalletBalanceResponse;
import com.project.wallet.dto.WalletDto;


public interface WalletService {
	
    UserResponse addBalance(WalletDto request);
    WalletBalanceResponse getWalletBalance(Long userId);
    TransferResponse transferFunds(TransferRequest request);
    
}
