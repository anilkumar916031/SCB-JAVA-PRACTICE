package com.project.wallet.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.project.wallet.dto.UserDto;
import com.project.wallet.dto.UserResponse;
import com.project.wallet.entity.User;
import com.project.wallet.exception.InvalidRequestException;
import com.project.wallet.repository.UserRepository;
import com.project.wallet.service.UserService;

@Service
public class UserServiceImpl implements UserService {

    @Autowired
    private UserRepository userRepository;

    @Override
    public UserResponse registerUser(UserDto request) {
        if (userRepository.existsByEmail(request.getEmail())) {
            throw new InvalidRequestException("Email already exists");
        }

        User user = new User();
        user.setUsername(request.getUsername());
        user.setPassword(request.getPassword());
        user.setEmail(request.getEmail());

        User savedUser = userRepository.save(user);
        String selfLink = "http://localhost:8090/users/" + savedUser.getId();
        return new UserResponse("User account created successfully", selfLink);
    }

	
}
